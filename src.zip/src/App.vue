<template>
    <div>
        <iv-visualisation :title=titleText>
            <template #hotspots>

                <iv-toggle-hotspot position="right" title="Sliders" style="z-index:2; width:20vw;" >
                        <div id="CartesianSliders" v-if="tabSelected == 0" style="overflow: hidden; width:20vw;">
                            
                            <label for="xslider" style="border-left: solid 5px rgb(219,209,0); padding-left: 8px;" > x-coordinate: </label>
                            <iv-slider id="xslider"  @sliderChanged="slider1Change" theme="Lime" min=-3 max=3 init_val=1 step=0.1 tick_step=1 />

                            <label for="yslider" style="border-left: solid 5px rgb(182,109,255); padding-left: 8px;" > y-coordinate: </label>
                            <iv-slider id="yslider"  @sliderChanged="slider2Change" theme="Lime" min=-3 max=3 init_val=1 step=0.1 tick_step=1 />

                            <label for="zslider" style="border-left: solid 5px rgb(0,146,146); padding-left: 8px;" > z-coordinate: </label>
                            <iv-slider id="zslider"  @sliderChanged="slider3Change" theme="Lime" min=-3 max=3 init_val=1 step=0.1 tick_step=1 />
                            
                        </div>
                        <div id="CylindricalSliders" v-if="tabSelected == 1" style="overflow: hidden; width:20vw;">

                            <label for="4slider" style="border-left: solid 5px rgb(219,209,0); padding-left: 8px;" > ρ-coordinate: </label>
                            <iv-slider id="4slider"  @sliderChanged="slider4Change" theme="Lime" min=0 max=3 init_val=1 step=0.1 tick_step=0.5 />

                            <label for="5slider" style="border-left: solid 5px rgb(182,109,255); padding-left: 8px;" > φ-coordinate: </label>
                            <iv-slider id="5slider"  @sliderChanged="slider5Change" theme="Lime" min=-180 max=180 init_val=1 step=10 tick_step=60 />

                            <label for="6slider" style="border-left: solid 5px rgb(0,146,146); padding-left: 8px;" > z-coordinate: </label>
                            <iv-slider id="6slider"  @sliderChanged="slider6Change" theme="Lime" min=-3 max=3 init_val=1 step=0.1 tick_step=60 />

                        </div> 
                        <div id="SphericalSliders" v-if="tabSelected == 2" style="overflow: hidden; width:20vw;">
                            <label for="7slider" style="border-left: solid 5px rgb(219,209,0); padding-left: 8px;" > r-coordinate: </label>
                            <iv-slider id="7slider"  @sliderChanged="slider7Change" theme="Lime" min=0 max=3 init_val=1 step=0.1 tick_step=0.5 />

                            <label for="8slider" style="border-left: solid 5px rgb(182,109,255); padding-left: 8px;" > θ-coordinate: </label>
                            <iv-slider id="8slider"  @sliderChanged="slider8Change" theme="Lime" min=0 max=180 init_val=1 step=10 tick_step=60 />

                            <label for="9slider" style="border-left: solid 5px rgb(0,146,146); padding-left: 8px;" > φ-coordinate: </label>
                            <iv-slider id="9slider"  @sliderChanged="slider9Change" theme="Lime" min=-180 max=180 init_val=1 step=10 tick_step=60 />
                        </div> 
                        
                </iv-toggle-hotspot>

                <iv-pane position="left">
                    <iv-sidebar-content :showPagination="true">
                        <iv-sidebar-section :title="textTitle1">
                            Use the tabs at the top to switch between different coordinate systems, and use the toggle hotspot at the bottom to
                            adjust the coordinates.
                            <br>
                            <img src="../asset/RHR.png" alt="Image of a hand depicting the right hand rule">
                            
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>
            </template>

            <div class="iv-welcome-message">
                <h2>Select Coordinate System:</h2>
                <iv-toggle-advance :modes=modeNames @toggleswitched="toggleChange"></iv-toggle-advance>
                <h3>Basis Vectors:</h3>
                <div id='graph' style="width:450px; height:450px; background-color:blue;"></div>
            </div>
        </iv-visualisation>
    </div>
</template>
<script>
import {name} from '../package.json';
import Plotly from 'plotly.js/dist/plotly.min.js';
import $ from 'jquery';
import numeric from 'numeric';
import math from 'math';

export default {
    name:"App",
    data(){
        return {
            projectName: name,
            textTitle1: "Instructions",
            slider1: 1,
            slider2: 1,
            slider3: 1,
            slider4: 1,
            slider5: 1,
            slider6: 1,
            slider7: 1,
            slider8: 1,
            slider9: 1,
            redrawPlot: false,
            tabSelected: 0
        }
    },
    methods: {
        slider1Change(e){
            this.slider1 = e;
            this.redrawPlot = true;
        },
        slider2Change(e){
            this.slider2 = e;
            this.redrawPlot = true;
        },
        slider3Change(e){
            this.slider3 = e;
            this.redrawPlot = true;
        },
        slider4Change(e){
            this.slider4 = e;
            this.redrawPlot = true;
        },
        slider5Change(e){
            this.slider5 = e;
            this.redrawPlot = true;
        },
        slider6Change(e){
            this.slider6 = e;
            this.redrawPlot = true;
        },
        slider7Change(e){
            this.slider7 = e;
            this.redrawPlot = true;
        },
        slider8Change(e){
            this.slider8 = e;
            this.redrawPlot = true;
        },
        slider9Change(e){
            this.slider9 = e;
            this.redrawPlot = true;
        },
        toggleChange(e){
            this.tabSelected = e;
            this.redrawPlot = true;
        }
    },
    props: {
        titleText:{
            default: "Basis Vector in Curvilinear Coordinates",
        },
        modeNames:{
            default: ["Cartesian","Cylindrical","Spherical"],
        },
        slider1Name:{
            default: "x",
        }

        
    },
    mounted(){
        let v = this;

        // Colour definitions:
            let impBlue = "#003E74",
            black = "rgb(0,0,0)",
            white = "rgb(255,255,255)",
            cyan = "rgb(0,146,146)", //1
            lilac = "rgb(182,109,255)", //2
            orange = "rgb(219,209,0)"; //3

        // Plot Utilities:
        /**
         * sets camera options in layout.
         * @param {array} point - point of viewpoint.
         */
        function createView(point) {
        let norm = Math.sqrt(point[0]*point[0] + (5*point[1])*(5*point[1]) + point[2]*point[2]);
        let a = 0.5 + point[0]/norm, b = 1 +  5*point[1]/norm, c = 0.5 + point[2]/norm;
        let camera = {
            up: {x: 0, y: 0, z: 1},
            eye: {x: -a, y: -b, z: c + 0.5},
            center: {x: 0, y: 0, z: -0.2}
        }
        return camera
        }


        // Change of Basis:
        /**
         * changes spherical to cartesian coordinates
         * @param {float} r - r.
         * @param {float} theta - theta.
         * @param {float} phi - phi.
         */
        function sp2c(r,theta,phi) {
            return [
                r * Math.sin(theta) * Math.cos(phi),
                r * Math.sin(theta) * Math.sin(phi),
                r * Math.cos(theta)
            ];
        }
        /**
         * changes cartesian to spherical coordinates
         * @param {float} x - x.
         * @param {float} y - y.
         * @param {float} z - z.
         */
        function c2sp(x,y,z) {
            let r = 0, theta = 0, phi = 0;
            if (x*x + y*y + z*z !== 0) {
                r = Math.sqrt(x*x + y*y + z*z);
                theta = Math.acos(z/r);
                phi = Math.atan2(y,x);
            }
            return [r, theta, phi];
        }


        ///Shape Objects:
        //3D Objects:
        /**
         * Represents a line.
         * @constructor
         * @param {list} points - list of the points in the line.
         */
        function Line(points) {
            this.x = [];
            this.y = [];
            this.z = [];
            for (let i = 0; i  < points.length; ++i) {
                this.x.push(points[i][0]);
                this.y.push(points[i][1]);
                this.z.push(points[i][2]);
            }

            this.gObject = function(color, width=7, dash="solid") {
                let lineObject = {
                    type: "scatter3d",
                    mode: "lines",
                    x: this.x,
                    y: this.y,
                    z: this.z,
                    line: {color: color, width: width, dash:dash}
                }
                return lineObject;
            }

            this.arrowHead = function(color, width=7, wingLen=0.1) {
                let lastElm = this.x.length - 1;
                let [r, theta, phi] = c2sp(this.x[lastElm]-this.x[0], this.y[lastElm]-this.y[0], this.z[lastElm]-this.z[0]);
                let offset = [this.x[0], this.y[0], this.z[0]];
                let frac = wingLen*r;
                let sin45 = Math.sin(Math.PI/4);
                let d = r - frac * sin45;
                let wingLength = Math.sqrt(Math.pow(frac*sin45,2) + d*d);
                let wingAngle = Math.acos(d/wingLength);


                let wings_xyz = [
                    math.add(sp2c(wingLength, theta + wingAngle, phi), offset),
                    math.add(sp2c(wingLength, theta - wingAngle, phi), offset)
                ];

                let wings = {
                    type: "scatter3d",
                    mode: "lines",
                    x: [wings_xyz[0][0], this.x[lastElm], wings_xyz[1][0]],
                    y: [wings_xyz[0][1], this.y[lastElm], wings_xyz[1][1]],
                    z: [wings_xyz[0][2], this.z[lastElm], wings_xyz[1][2]],
                    line: {color: color, width: width}
                }

                return wings;
            }
        }
        /**
         * Represents a point.
         * @constructor
         * @param {array} position - position of the point.
         */
        // function Point(position) {
        //     this.position = position;
        //     this.gObject = function(color, size = 7, symbol="circle") {
        //         let pointObject = {
        //             type: "scatter3d",
        //             mode: "markers",
        //             x: [this.position[0]],
        //             y: [this.position[1]],
        //             z: [this.position[2]],
        //             marker: {"color": color, "size": size, "symbol": symbol}
        //         }
        //         return pointObject;
        //     }
        // }
        /**
         * Represents a sphere.
         * @constructor
         * @param {float} radius - radius of the sphere.
         */
        function Sphere(radius) {
            this.radius = radius;
            let meshSize = 20;
            let theta = numeric.linspace(0, Math.PI, meshSize);
            let phi = numeric.linspace(0, 2*Math.PI, meshSize);
            this.x = [], this.y = [], this.z = [];
            for(let i = 0; i < meshSize; ++i) {
                this.x[i] = [], this.y[i] = [], this.z[i] = [];
                for(let j = 0; j < meshSize; ++j) {
                    this.x[i].push(radius*Math.cos(phi[i])*Math.sin(theta[j]));
                    this.y[i].push(radius*Math.sin(phi[i])*Math.sin(theta[j]));
                    this.z[i].push(radius*Math.cos(theta[j]));
                }
            }
            this.gObject = function(color1, color2) {
                let sphere = {
                    type: "surface",
                    x: this.x,
                    y: this.y,
                    z: this.z,
                    showscale: false,
                    opacity: 0.6,
                    colorscale: [[0.0, color1], [1.0, color2]]
                }
                return sphere;
            }
        }
        /**
         * Represents a cylinder.
         * @constructor
         * @param {float} radius - radius of the circular cross-section.
         * @param {float} height - height of the cylinder.
         */
        function Cylinder(radius, height){
            this.radius = radius;
            this.height = height;
            let meshSize = radius * 10;
            if (meshSize === 0) {meshSize = 2;}
            let phi = numeric.linspace(0, 2*Math.PI, meshSize);
            this.x = [], this.y = [], this.z = [];
            let hValue = numeric.linspace(-height, height, meshSize);

            let xTemp = [], yTemp = [];
            for(let i = 0; i < meshSize; ++i) {
                xTemp.push(radius*Math.cos(phi[i]));
                yTemp.push(radius*Math.sin(phi[i]));
            }
            for(let i = 0; i < meshSize; ++i) {
                this.x.push(xTemp);
                this.y.push(yTemp);
                this.z.push(numeric.rep([meshSize], hValue[i]));
            }
            console.log(this.x)
            console.log(this.z)
            this.gObjectCurve = function(color1, color2) {
                let curve = {
                    type: "surface",
                    x: this.x,
                    y: this.y,
                    z: this.z,
                    showscale: false,
                    opacity: 0.7,
                    colorscale: [[0.0, color1], [1.0, color2]]
                }
                return curve;
            }
            this.gObjectTop = function(color) {
                let top = {
                    type: "scatter3d",
                    mode: "lines",
                    x: this.x[0],
                    y: this.y[0],
                    z: this.z[meshSize - 1],
                    line: {color: color.slice(0, -1) + ",0.2)", width: 1},
                    surfaceaxis: 2,
                    opacity: 0.5
                }
                return top;
            }
            this.gObjectBottom = function(color) {
                let bottom = {
                    type: "scatter3d",
                    mode: "lines",
                    x: this.x[0],
                    y: this.y[0],
                    z: this.z[0],
                    line: {color: color.slice(0, -1) + ",0.7)", width: 1},
                    surfaceaxis: 2,
                    opacity: 0.7
                }
                return bottom;
            }
        }
        /**
         * Represents a cuboid.
         * @constructor
         * @param {float} x - half length of cuboid in x-direction.
         * @param {float} y - half length of cuboid in y-direction.
         * @param {float} z - half length of cuboid in z-direction.
         */
        function Cuboid(x, y, z){
            this.width = x,
            this.length = y,
            this.height = z,
            this.gObject = function(color) {
                let cuboid = {
                    type: "mesh3d",
                    x: [-x, -x, x, x, -x, -x, x, x],
                    y: [-y, y, y, -y, -y, y, y, -y],
                    z: [-z, -z, -z, -z, z, z, z, z],
                    i : [0, 0, 3, 4, 4, 4, 4, 4, 5, 6, 6, 7],
                    j : [2, 3, 4, 3, 6, 7, 1, 5, 2, 2, 7, 3],
                    k : [1, 2, 0, 7, 5, 6, 0, 1, 1, 5, 2, 2],
                    opacity: 0.5,
                    colorscale: [['0', color], ['1', "rgb(255,255,255)"]],
                    intensity: [0, 0.1, 0.3, 0.5, 0.7, 0.8, 0.9, 1],
                    showscale: false
                }
                return cuboid
            }
        }
        //2D Objects:

        

        //Global Initial Parameters:
        let initialPoint = [2, 2, 2];
        let layout = {
            width: 450,
            height: 500,
            margin: { l: 0, r: 0, t: 0, b: 0 },
            hovermode: "closest",
            showlegend: false,
            scene: {
                camera: createView([1, 1, 1]),
                xaxis: { range: [-6, 6], zeroline: true, autorange: false },
                yaxis: { range: [-6, 6], zeroline: true, autorange: false },
                zaxis: { range: [-6, 6], zeroline: true, autorange: false },
                aspectratio: { x: 1, y: 1, z: 1 },
            },
        };
        let currentPoint = initialPoint;
        let initialRho = 0,
            initialPhi = 0,
            initialR = 0,
            initialTheta = 0;

        //Plot
        /**
         * Resets and plots initial basis vectors.
         * @param {string} coor - type of coordinate systems.
         */
        function initPlot(coor) {
            console.log('intialPlot', coor);
            Plotly.purge("graph");

            if (coor == "Cartesian") {
                
                // $("#xController").val(currentPoint[0]);
                // $("#xControllerDisplay").text(currentPoint[0]);
                // $("#yController").val(currentPoint[1]);
                // $("#yControllerDisplay").text(currentPoint[1]);
                // $("#zController").val(currentPoint[2]);
                // $("#zControllerDisplay").text(currentPoint[2]);

                let x = v.slider1;
                let y = v.slider2;
                let z = v.slider3;


                

                Plotly.newPlot("graph", computeCartesian(x,y,z), layout);

            } else if (coor == "Cylindrical") {
                initialRho = Math.sqrt(
                    currentPoint[0] * currentPoint[0] +
                        currentPoint[1] * currentPoint[1]
                );
                initialPhi =
                    ((Math.atan2(currentPoint[1], currentPoint[0]) + 2 * Math.PI) %
                        (2 * Math.PI)) /
                    Math.PI;
                initialRho = Math.round(initialRho * 10) / 10;
                initialPhi = Math.round(initialPhi * 8) / 8;

                $("#rhoController").val(initialRho);
                $("#rhoControllerDisplay").text(initialRho);
                $("#phiController").val(initialPhi);
                $("#phiControllerDisplayA1").text(
                    "(" +
                        initialPhi * 8 +
                        "/8)" +
                        $("#phiControllerDisplayA1").attr("data-unit")
                );
                $("#phiControllerDisplayA2").text(
                    initialPhi * 180 + $("#phiControllerDisplayA2").attr("data-unit")
                );
                $("#z1Controller").val(currentPoint[2]);
                $("#z1ControllerDisplay").text(currentPoint[2]);

                let rho = v.slider4;
                let phi = v.slider5 * Math.PI/180;
                let z = v.slider6;

                Plotly.newPlot("graph", computeCylindrical(rho, phi, z), layout);
            } else if (coor == "Spherical") {
                initialR = Math.sqrt(
                    currentPoint[0] * currentPoint[0] +
                        currentPoint[1] * currentPoint[1] +
                        currentPoint[2] * currentPoint[2]
                );
                initialTheta =
                    Math.atan2(
                        Math.sqrt(
                            currentPoint[0] * currentPoint[0] +
                                currentPoint[1] * currentPoint[1]
                        ),
                        currentPoint[2]
                    ) / Math.PI;
                initialPhi =
                    ((Math.atan2(currentPoint[1], currentPoint[0]) + 2 * Math.PI) %
                        (2 * Math.PI)) /
                    Math.PI;
                initialR = Math.round(initialR * 10) / 10;
                initialTheta = Math.round(initialTheta * 8) / 8;
                initialPhi = Math.round(initialPhi * 8) / 8;

                $("#rController").val(initialR);
                $("#rControllerDisplay").text(initialR);
                $("#thetaController").val(initialTheta);
                $("#thetaControllerDisplayA1").text(
                    "(" +
                        initialTheta * 8 +
                        "/8)" +
                        $("#thetaControllerDisplayA1").attr("data-unit")
                );
                $("#thetaControllerDisplayA2").text(
                    initialTheta * 180 +
                        $("#thetaControllerDisplayA2").attr("data-unit")
                );
                $("#phi1Controller").val(initialPhi);
                $("#phi1ControllerDisplayA1").text(
                    "(" +
                        initialPhi * 8 +
                        "/8)" +
                        $("#phi1ControllerDisplayA1").attr("data-unit")
                );
                $("#phi1ControllerDisplayA2").text(
                    initialPhi * 180 + $("#phi1ControllerDisplayA2").attr("data-unit")
                );

                let r = v.slider7;
                let theta = v.slider8 * Math.PI/180;
                let phi = v.slider9 * Math.PI/180;

                Plotly.newPlot("graph", computeSpherical(r, theta, phi), layout);
            }
            return;
        }
        /**
        * Computes the basis vectors of the cartesian coordinate system.
        * @param {float} x - x value.
        * @param {float} y - y value.
        * @param {float} z - z value.
        */
        function computeCartesian(x, y, z) {
            console.log('ComputeCartesian');
            currentPoint = [
                x,
                y,
                z
            ];

            let xHat = new Line([
                    [x, y, z],
                    [x + 1, y, z],
                ]),
                yHat = new Line([
                    [x, y, z],
                    [x, y + 1, z],
                ]),
                zHat = new Line([
                    [x, y, z],
                    [x, y, z + 1],
                ]);

            let data = [
                new Cuboid(x, y, z).gObject(impBlue),
                xHat.gObject(orange, 5),
                xHat.arrowHead(orange, 5, 0.25),
                yHat.gObject(lilac, 5),
                yHat.arrowHead(lilac, 5, 0.25),
                zHat.gObject(cyan, 5),
                zHat.arrowHead(cyan, 5, 0.25),
            ];

            

            return data;
        }
        /**
        * Computes the basis vectors of the cylindrical coordinate system.
        * @param {float} rho - rho value.
        * @param {float} phi - phi value.
        * @param {float} z - z value.
        */
        function computeCylindrical(rho, phi, z) {
            let cylinder = new Cylinder(rho, z);
            let x = rho * Math.cos(phi);
            let y = rho * Math.sin(phi);
            currentPoint = [
                Math.round(x * 10) / 10,
                Math.round(y * 10) / 10,
                Math.round(z * 10) / 10,
            ];

            let meshSize = Math.round((phi / Math.PI) * 24);
            if (meshSize === 0) {
                meshSize = 2;
            }

            let t = numeric.linspace(0, phi, meshSize);
            let xTrace = [],
                yTrace = [],
                zTrace = [];
            for (let i = 0; i < meshSize; ++i) {
                xTrace[i] = rho * Math.cos(t[i]);
                yTrace[i] = rho * Math.sin(t[i]);
                zTrace[i] = z;
            }

            let rhoHat = new Line([
                    [x, y, z],
                    [x + Math.cos(phi), y + Math.sin(phi), z],
                ]),
                phiHat = new Line([
                    [x, y, z],
                    [x - Math.sin(phi), y + Math.cos(phi), z],
                ]),
                zHat = new Line([
                    [x, y, z],
                    [x, y, z + 1],
                ]);

            let data = [
                cylinder.gObjectCurve(impBlue, white),
                cylinder.gObjectTop("rgb(0,62,116)"),
                cylinder.gObjectBottom("rgb(0,62,116)"),
                rhoHat.gObject(orange, 5),
                rhoHat.arrowHead(orange, 5, 0.25),
                phiHat.gObject(lilac, 5),
                phiHat.arrowHead(lilac, 5, 0.25),
                zHat.gObject(cyan, 5),
                zHat.arrowHead(cyan, 5, 0.25),
                {
                    type: "scatter3d",
                    mode: "lines",
                    x: xTrace,
                    y: yTrace,
                    z: zTrace,
                    line: { color: black, width: 2 },
                },
            ];

            return data;
        }
        /**
        * Computes the basis vectors of the spherical coordinate system.
        * @param {float} r - rho value.
        * @param {float} theta - theta value.
        * @param {float} phi - phi value.
        */
        function computeSpherical(r, theta, phi) {
            let sphere = new Sphere(r);
            let x = r * Math.cos(phi) * Math.sin(theta);
            let y = r * Math.sin(phi) * Math.sin(theta);
            let z = r * Math.cos(theta);
            currentPoint = [
                Math.round(x * 10) / 10,
                Math.round(y * 10) / 10,
                Math.round(z * 10) / 10,
            ];

            let rHat = new Line([
                    [x, y, z],
                    [
                        x + Math.cos(phi) * Math.sin(theta),
                        y + Math.sin(phi) * Math.sin(theta),
                        z + Math.cos(theta),
                    ],
                ]),
                thetaHat = new Line([
                    [x, y, z],
                    [
                        x + Math.cos(phi) * Math.cos(theta),
                        y + Math.sin(phi) * Math.cos(theta),
                        z - Math.sin(theta),
                    ],
                ]),
                phiHat = new Line([
                    [x, y, z],
                    [x - Math.sin(phi), y + Math.cos(phi), z],
                ]);
            let data = [
                sphere.gObject(impBlue, white),
                rHat.gObject(cyan, 5),
                rHat.arrowHead(cyan, 5, 0.25),
                thetaHat.gObject(orange, 5),
                thetaHat.arrowHead(orange, 5, 0.25),
                phiHat.gObject(lilac, 5),
                phiHat.arrowHead(lilac, 5, 0.25),
            ];
            let meshSize, t;
            let xTrace = [],
                yTrace = [],
                zTrace = [];

            meshSize = Math.round((phi / Math.PI) * 24);
            if (meshSize === 0) {
                meshSize = 2;
            }
            t = numeric.linspace(0, phi, meshSize);
            for (let i = 0; i < meshSize; ++i) {
                xTrace[i] = r * Math.cos(t[i]) * Math.sin(theta);
                yTrace[i] = r * Math.sin(t[i]) * Math.sin(theta);
                zTrace[i] = z;
            }

            data.push({
                type: "scatter3d",
                mode: "lines",
                x: xTrace,
                y: yTrace,
                z: zTrace,
                line: { color: black, width: 2 },
            });

            xTrace = [];
            yTrace = [];
            zTrace = [];

            meshSize = Math.round((theta / Math.PI) * 24);
            if (meshSize === 0) {
                meshSize = 2;
            }
            t = numeric.linspace(0, theta, meshSize);
            for (let i = 0; i < meshSize; ++i) {
                xTrace[i] = r * Math.cos(phi) * Math.sin(t[i]);
                yTrace[i] = r * Math.sin(phi) * Math.sin(t[i]);
                zTrace[i] = r * Math.cos(t[i]);
            }

            data.push({
                type: "scatter3d",
                mode: "lines",
                x: xTrace,
                y: yTrace,
                z: zTrace,
                line: { color: black, width: 2 },
            });

            return data;
        }

        /** updates the plot according to the slider controls. */
        function updatePlot() {
            let data = [];
            let href = v.tabSelected;

            if (href == 0) {
                let x = v.slider1;
                let y = v.slider2;
                let z = v.slider3;
                console.log(x,y,z);
                data = computeCartesian(x, y, z);
            } else if (href == 1) {
                let rho = v.slider4;
                let phi = v.slider5 * Math.PI/180; 
                let z = v.slider6;
                data = computeCylindrical(rho, phi, z);
            } else if (href == 2) {
                let r = v.slider7;
                let theta = v.slider8 * Math.PI/180;
                let phi = v.slider9 * Math.PI/180;
                data = computeSpherical(r, theta, phi);
            }

            Plotly.animate(
                "graph",
                { data: data },
                {
                    fromcurrent: true,
                    transition: { duration: 0 },
                    frame: { duration: 0, redraw: true },
                    mode: "immediate",
                }
            );
        }

        function main() {
            // $("input[type=range]").each(function () {
            //     let displayEl;
            //     $(this).on("input", function () {
            //         $("#" + $(this).attr("id") + "Display").text(
            //             $(this).val() +
            //                 $("#" + $(this).attr("id") + "Display").attr("data-unit")
            //         );
            //         $("#" + $(this).attr("id") + "DisplayA2").text(
            //             parseFloat($(this).val()) * 180 +
            //                 $("#" + $(this).attr("id") + "DisplayA2").attr("data-unit")
            //         );

            //         if ((parseFloat($(this).val()) * 8) % 8 === 0.0) {
            //             displayEl = $(this).val();
            //         } else if ((parseFloat($(this).val()) * 8) % 4 === 0.0) {
            //             displayEl = "(" + $(this).val() * 2 + "/2)";
            //         } else if ((parseFloat($(this).val()) * 8) % 2 === 0.0) {
            //             displayEl = "(" + $(this).val() * 4 + "/4)";
            //         } else {
            //             displayEl = "(" + $(this).val() * 8 + "/8)";
            //         }
            //         $("#" + $(this).attr("id") + "DisplayA1").text(
            //             displayEl +
            //                 $("#" + $(this).attr("id") + "DisplayA1").attr("data-unit")
            //         );
            //         updatePlot();
            //     });
            // });

            $(function () {
                $("ul.tab-nav li a.button").click(function () {
                    let href = v.tabSelected;
                    $("li a.active.button", $(this).parent().parent()).removeClass(
                        "active"
                    );
                    $(this).addClass("active");
                    $(".tab-pane.active", $(href).parent()).removeClass("active");
                    $(href).addClass("active");

                    initPlot(href);
                    return false;
                });
            });
            initPlot("Cartesian");
        }

        function animate() {
            requestAnimationFrame(animate);

            if(v.redrawPlot){
                updatePlot();
                v.redrawPlot = false;
            }
        }
        animate();

        main()
    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
</style>